import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Objeto {

    private int ID;
    private int CantidadCritica;
    private int Cantidad = 1;
    private String Categoria;
    private String Nombre;
    private String Desc;
    private String Proveedor;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public Objeto(int id, int cantidadCritica, String categoria, String nombre, String desc, String proveedor) {
        ID = id;
        CantidadCritica = cantidadCritica;
        Categoria = categoria;
        Nombre = nombre;
        Desc = desc;
        Proveedor = proveedor;
    }

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public int getID() {
        return ID;
    }

    public int getCantidadCritica() {
        return CantidadCritica;
    }

    public int getCantidad() {
        return Cantidad;
    }

    public String getCategoria() {
        return Categoria;
    }

    public String getNombre() {
        return Nombre;
    }

    public String getDesc() {
        return Desc;
    }

    public String getProveedor() {
        return Proveedor;
    }




     public boolean validarID(int idComparada) {
        return ID == idComparada;
    }


}
