import java.util.ArrayList;

public class Empresa {

    private ArrayList<Objeto> Inventario;
    private String Nombre;
    private int Presupuesto;




}
